﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Shared.StringManipulation
{
    public interface IStringManipulationService
    {
        string standarizeText(string text);
    }
}
