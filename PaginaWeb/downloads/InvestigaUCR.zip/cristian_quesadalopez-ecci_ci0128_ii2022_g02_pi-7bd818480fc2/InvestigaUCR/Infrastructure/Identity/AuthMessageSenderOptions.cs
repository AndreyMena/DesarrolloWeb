﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Identity
{
    public class AuthMessageSenderOptions
    {
        // Key used for sendGrid packadge for the email confirmation
        //public string? SendGridKey { get; set; }
        public string? SendGridKey = "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";

    }
}
