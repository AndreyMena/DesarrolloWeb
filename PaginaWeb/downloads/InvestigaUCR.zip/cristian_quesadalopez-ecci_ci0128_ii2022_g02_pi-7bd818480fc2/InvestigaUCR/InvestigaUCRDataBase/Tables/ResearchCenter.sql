﻿CREATE TABLE [dbo].[ResearchCenter]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(MAX) NOT NULL
)
