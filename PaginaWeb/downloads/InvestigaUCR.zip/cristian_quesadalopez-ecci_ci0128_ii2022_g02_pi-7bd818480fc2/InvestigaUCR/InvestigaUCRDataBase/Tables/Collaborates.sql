﻿CREATE TABLE [dbo].[Collaborates]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [PersonalIdentification] INT NOT NULL
)
