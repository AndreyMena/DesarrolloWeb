﻿CREATE TABLE [dbo].[Associates_RA]
(
	[Project_ID] VARCHAR(30) NOT NULL, 
    [Area_ID] INT NOT NULL,
	PRIMARY KEY (Project_ID, Area_ID)
)
