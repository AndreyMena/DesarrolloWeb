﻿--CREATE TABLE [dbo].[Thesis](
--	[ID] [int] NOT NULL,
--	[Title] [varchar](100) NULL,
--	[_Type] [varchar](30) NULL,
--	[Description] [varchar](5000) NULL,
--	[_Date] [date] NULL,
--	[ResearchProjectId] [varchar](50) NULL,
	
--	PRIMARY KEY (ID),
--	FOREIGN KEY (ResearchProjectId) REFERENCES ResearchProject(Id)
--	)
