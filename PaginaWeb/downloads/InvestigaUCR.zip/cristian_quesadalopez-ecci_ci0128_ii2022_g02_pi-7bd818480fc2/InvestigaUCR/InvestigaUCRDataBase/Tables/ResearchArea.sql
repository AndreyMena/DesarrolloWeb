﻿CREATE TABLE [dbo].[ResearchArea]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(50) NULL, 
    [Description] NVARCHAR(MAX) NULL
)
