# SpiteAndMalice

## Ejecutar

Para ejecutar el programa, se ha agregado una nueva carpeta llamada "exe"
en la que se puede encontrar la aplicación "MARDA.exe", este ejecutable esta 
creado en la version funcional mas reciente del programa. Si se desea compilar 
y ejecutar por aparte, se debe tener Qt creator instalado en el computador,
dentro de la carpeta "MARDA" se encuentra "MARDA.pro" para abrir el proyecto
en QT.

Nota: Si no se tiene Qt instalado puede que algunas interfaces visuales pueden 
diferir del trabajo actual.
